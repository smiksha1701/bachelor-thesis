#! /usr/bin/env sh
latexmk -pdf -pvc main.tex
